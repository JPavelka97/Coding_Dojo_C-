using Microsoft.AspNetCore.Mvc;
using SurveyRedux.Models;
namespace SurveyRedux.Controllers;
public class SurveyController : Controller
{

    [HttpGet("")]
    public ViewResult Index()
    {
        return View("index");
    }

    [HttpPost("process")]
    public ViewResult Process(Survey survey) 
    {
        return View("results", survey);
    }

    [HttpGet("results")]
    public ViewResult Results()
    {
        return View("results");
    }
}
